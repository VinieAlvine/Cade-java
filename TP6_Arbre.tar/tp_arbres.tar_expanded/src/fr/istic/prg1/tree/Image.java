package fr.istic.prg1.tree;

import java.util.Scanner;

import fr.istic.prg1.tree.util.AbstractImage;
//import fr.istic.prg1.tree_util.AbstractImage;
import fr.istic.prg1.tree_util.Iterator;

import fr.istic.prg1.tree_util.Node;
import fr.istic.prg1.tree_util.NodeType;


/**
 * @author Mickaël Foursov <foursov@univ-rennes1.fr>
 * @modify Tchimou Alvine && Morvan Olwen
 * @version 5.0
 * @since 2023-09-23
 * 
 *        Classe décrivant les images en noir et blanc de 256 sur 256 pixels
 *        sous forme d'arbres binaires.
 * 
 */

public class Image extends AbstractImage {
	private static final Scanner standardInput = new Scanner(System.in);

	public Image() {
		super();
	}

	public static void closeAll() {
		standardInput.close();
	}

	/**
	 * this devient identique à image2.
	 *
	 * @param image2 image à copier
	 *
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void affect(AbstractImage image2) {

		Iterator<Node>it=this.iterator();
		Iterator<Node>it2=image2.iterator();
		it.clear();// on vide l'itérateur
		affectAux(it,it2);
	}
	public  void affectAux(Iterator<Node>it,Iterator<Node>it2){
		// parcours préfixe : racine puis,récursivement s/arbre gauche puis droit
		int val =it2.getValue().state;
		it.addValue(Node.valueOf(val));// on ajoute  les valeurs 
		if(val==2){
			it.goLeft();
			it2.goLeft();
			affectAux(it,it2);
			it.goUp();
			it2.goUp(); 
			it.goRight();
			it2.goRight();
			affectAux(it,it2);
			it.goUp();
			it2.goUp();


		}
	}

	/**
	 * this devient rotation de image2 à 180 degrés.
	 *
	 * @param image2 image pour rotation
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void rotate180(AbstractImage image2) {
		//Permuter les nœuds gauche et droite a chaque fois

		Iterator<Node>it=this.iterator();
		Iterator<Node>it2=image2.iterator();
		it.clear();
		rotate180(it,it2);
	}
	public void rotate180(Iterator<Node>it,Iterator<Node>it2) {

		int val =it2.getValue().state;
		it.addValue(Node.valueOf(val));
		if(val==2){
			it.goRight();
			it2.goLeft();
			rotate180(it,it2);
			it.goUp();
			it2.goUp(); 
			it.goLeft();
			it2.goRight();
			rotate180(it,it2);
			it.goUp();
			it2.goUp();
		}
	}

	/**
	 * this devient inverse vidéo de this, pixel par pixel.
	 *
	 * @pre !image.isEmpty()
	 */
	@Override
	public void videoInverse() {
		Iterator<Node>it=this.iterator();
		AuxvideoInverse( it);
	}

	public void AuxvideoInverse(Iterator <Node> it) {
		// on fait un parcourt prifixe en inversant les state : 0->1 et 1->0
		if(!it.isEmpty()) {
			switch(it.getValue().state) {
			case 0 :it.setValue(Node.valueOf(1));
			break;
			case 1 :it.setValue(Node.valueOf(0));
			break;
			default : it.goLeft();
			          AuxvideoInverse(it);
			          it.goUp();
			          it.goRight();
			          AuxvideoInverse(it);
			          it.goUp();
			}

		}
	}

	/**
	 * this devient image miroir verticale de image2.
	 *
	 * @param image2 image à agrandir
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void mirrorV(AbstractImage image2) {
		//permuter les enfants des nœuds de profondeur pair
		Iterator<Node>it=this.iterator();
		Iterator<Node>it2=image2.iterator();
		it.clear();
		auxmirrorV(it,it2,0);
	}

	public void auxmirrorV(Iterator<Node>it,Iterator<Node>it2,int i) {
		int val =it2.getValue().state;
		it.addValue(Node.valueOf(val));
		if (val==2) {
			it2.goLeft();
			if (i % 2 !=0 ) {
				it.goLeft();
			} else {
				it.goRight();
			}
			auxmirrorV(it, it2, ++i);

			it.goUp();
			it2.goUp();
			--i;

			it2.goRight();
			if (i % 2 != 0) {
				it.goRight();
			} else {
				it.goLeft();
			}
			auxmirrorV(it, it2, ++i);

			it.goUp();
			it2.goUp();
			--i;
		}
	}



	/**
	 * this devient image miroir horizontale de image2.
	 *
	 * @param image2 image à agrandir
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void mirrorH(AbstractImage image2) {
		Iterator<Node>it=this.iterator();
		Iterator<Node>it2=image2.iterator();
		it.clear();
		auxmirrorH(it,it2,0);
	}
	public void auxmirrorH(Iterator<Node>it,Iterator<Node>it2,int i) {
		//permuter les enfants des nœuds de profondeur impair
		int val =it2.getValue().state;
		it.addValue(Node.valueOf(val));
		if (val==2) {
			it2.goLeft();
			if (i % 2 == 0) {
				it.goLeft();
			} else {
				it.goRight();
			}
			auxmirrorH(it, it2, ++i);

			it.goUp();
			it2.goUp();
			--i;

			it2.goRight();
			if (i % 2 == 0) {
				it.goRight();
			} else {
				it.goLeft();
			}
			auxmirrorH(it, it2, ++i);

			it.goUp();
			it2.goUp();
			--i;
		}
	}

	/**
	 * this devient quart supérieur gauche de image2.
	 *
	 * @param image2 image à agrandir
	 * 
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void zoomIn(AbstractImage image2) {
		Iterator<Node>it2=image2.iterator();
		Iterator<Node>it=this.iterator();
		it.clear();
		if(it2.getValue().state==2) {
			it2.goLeft(); // on va à gauche 
			if(it2.getValue().state==2) {
				// si c'est un noeuds double , on va à gauche 
				it2.goLeft();
			}
			affectAux(it,it2); 
		}
	}

	/**
	 * Le quart supérieur gauche de this devient image2, le reste de this devient
	 * éteint.
	 * 
	 * @param image2 image à réduire
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void zoomOut(AbstractImage image2) {

		Iterator<Node> it = this.iterator();
		Iterator<Node> it2 = image2.iterator();
		it.clear();
		it.addValue(Node.valueOf(2));
		it.goRight();
		it.addValue(Node.valueOf(0));
		it.goUp();
		it.goLeft();
		it.addValue(Node.valueOf(2));
		it.goRight();
		it.addValue(Node.valueOf(0));
		it.goUp();
		it.goLeft();
		zoomOutAux(it, it2, 0);
		if (it.getValue().state == 0) {
			it.goRoot();
			it.clear();
			it.addValue(Node.valueOf(0));
		}
	}

	public void zoomOutAux(Iterator<Node> it, Iterator<Node> it2, int cmpt) {
		if (it2.nodeType() == NodeType.DOUBLE) {
			if (cmpt < 14) {
				it.addValue(it2.getValue());
				it.goLeft();
				it2.goLeft();
				zoomOutAux(it, it2, cmpt + 1);
				int left = it.getValue().state;
				it.goUp();
				it2.goUp();
				it.goRight();
				it2.goRight();
				zoomOutAux(it, it2, cmpt + 1);
				int right = it.getValue().state;
				it.goUp();
				it2.goUp();
				if (left == right && left != 2) {
					it.clear();
					it.addValue(Node.valueOf(right));
				}
			} else {
				if (it2.getValue().state != 2) {
					it.addValue(Node.valueOf(it2.getValue().state));
				} else {
					it2.goLeft();
					int left = it2.getValue().state;
					it2.goUp();
					it2.goRight();
					int right = it2.getValue().state;
					it2.goUp();
					if (right == 1 || left == 1) {
						it.addValue(Node.valueOf(1));
					} else if (right == 2 && left == 2) {
						it.addValue(Node.valueOf(1));
					} else {
						it.addValue(Node.valueOf(0));
					}
				}
			}
		} else {
			it.addValue(Node.valueOf(it2.getValue().state));
		}
	}



	/**
	 * this devient l'intersection de image1 et image2 au sens des pixels allumés.
	 * 
	 * @pre !image1.isEmpty() && !image2.isEmpty()
	 * 
	 * @param image1 premiere image
	 * @param image2 seconde image
	 */
	@Override
	public void intersection(AbstractImage image1, AbstractImage image2) {
		Iterator <Node> it = this.iterator();
		it.clear();
		Iterator <Node> it1 = image1.iterator();
		Iterator <Node> it2 = image2.iterator();
		intersectionAux(it,it1,it2);
	}
	public  void intersectionAux(Iterator <Node> it,Iterator <Node> it1,Iterator <Node> it2){

		if (it1.getValue().state == 2 && it2.getValue().state == 2){
			it1.goLeft();
			it2.goLeft();
			it.addValue(Node.valueOf(2));
			it.goLeft();
			intersectionAux(it,it1,it2);
			int valL =it.getValue().state;
			it1.goUp();
			it2.goUp();
			it.goUp();
			it1.goRight();
			it2.goRight();
			it.goRight();
			intersectionAux(it,it1,it2);
			int valR =it.getValue().state;
			it1.goUp();
			it2.goUp();
			it.goUp();
			// si le noeufs courant à 2 fils = 0
			if(valR==0 && valL==0) {
				it.clear();
				it.addValue(Node.valueOf(0));
			}
		}
		if (it1.getValue().state == 2 && it2.getValue().state == 1){
			affectAux(it,it1);
		}
		if (it1.getValue().state == 1 && it2.getValue().state == 2){
			affectAux(it,it2);
		}
		if (it1.getValue().state == 0 || it2.getValue().state == 0){
			it.addValue(Node.valueOf(0));
		}

		if (it1.getValue().state == 1 && it2.getValue().state == 1){
			it.addValue(Node.valueOf(1));

		}
	}

	/**
	 * this devient l'union de image1 et image2 au sens des pixels allumés.
	 * 
	 * @pre !image1.isEmpty() && !image2.isEmpty()
	 * 
	 * @param image1 premiere image
	 * @param image2 seconde image
	 */
	@Override
	public void union(AbstractImage image1, AbstractImage image2) {
		Iterator <Node> it1 = image1.iterator();
		Iterator <Node> it2 = image2.iterator();
		Iterator <Node> it = this.iterator();
		it.clear();
		auxunion(it,it1,it2);
	}
	public void auxunion(Iterator<Node>it,Iterator<Node>it1,Iterator<Node>it2) {
		int val =it1.getValue().state;
		int val2 =it2.getValue().state;

		if(val==2 && val2==2) {
			it.addValue(Node.valueOf(2));
			it1.goLeft();
			it2.goLeft();
			it.goLeft();
			auxunion(it,it1,it2);
			int valL =it.getValue().state;
			it1.goUp();
			it2.goUp();
			it.goUp();
			it1.goRight();
			it2.goRight();
			it.goRight();
			auxunion(it,it1,it2);
			int valR =it.getValue().state;
			it1.goUp();
			it2.goUp();
			it.goUp();
			// si le noeufs courant à 2 fils = 0
			if(valR==valL && valL!=2) {
				it.clear();
				it.addValue(Node.valueOf(valR));}
		}
		else if(val==0&&val2==0) {
			it.addValue(Node.valueOf(0));
		}
		else if((val==0&&val2==2)){
			affectAux(it,it2);

		}
		else if((val==2&&val2==0)){
			affectAux(it,it1);
		}
		else  {
			it.addValue(Node.valueOf(1));
		}

	}

	/**
	 * Attention : cette fonction ne doit pas utiliser la commande isPixelOn
	 * 
	 * @return true si tous les points de la forme (x, x) (avec 0 <= x <= 255)
	 *         sont allumés dans this, false sinon
	 */
	@Override
	public boolean testDiagonal() {
		Iterator<Node> it = this.iterator();
		return testDiagonalAux(it);
	}
	public boolean testDiagonalAux(Iterator<Node> it) {
		if (it.getValue().state == 2) {
			boolean left = false;
			it.goLeft();
			if (it.getValue().state == 2) {
				it.goLeft();
				left = testDiagonalAux(it);
				it.goUp();
			} else {
				left = it.getValue().state == 1;
			}
			it.goUp();
			if (left) {
				boolean right = false;
				it.goRight();
				if (it.getValue().state == 2) {
					it.goRight();
					right = testDiagonalAux(it);
					it.goUp();
				} else {
					right = it.getValue().state == 1;
				}
				it.goUp();
				return right;
			}
		}
		return it.getValue().state == 1;
	}
	/**
	 * @param x abscisse du point
	 * @param y ordonnée du point
	 * @pre !this.isEmpty()
	 * @return true, si le point (x, y) est allumé dans this, false sinon
	 */
	@Override
	public boolean isPixelOn(int x, int y) {
		Iterator <Node> it = this.iterator();
		int x1 = 0;
		int x2 = 255;
		int y1 = 0;
		int y2 = 255;
		int v = 0;
		return isPixelOnAux(it,v,x,y,x1,x2,y1,y2);
	}

	public boolean isPixelOnAux(Iterator <Node> it,int v,int x,int y,int x1,int x2,int y1,int y2){
		int val =it.getValue().state;
		if(val==2){
			if(v == 0){
				if(y>(y1+y2)/2){
					it.goRight();
					y1 = (y1+y2)/2;
					v = 1;
					return isPixelOnAux(it,v,x,y,x1,x2,y1,y2)	;
				}else{
					it.goLeft();
					y2 = (y1+y2)/2;
					v = 1;
					return isPixelOnAux(it,v,x,y,x1,x2,y1,y2);
				}
			}else{
				if(x>(x1+x2)/2){
					it.goRight();
					x1 = (x1+x2)/2;
					v = 0;
					return isPixelOnAux(it,v,x,y,x1,x2,y1,y2)	;
				}else{
					it.goLeft();
					x2 = (x1+x2)/2;
					v = 0;
					return isPixelOnAux(it,v,x,y,x1,x2,y1,y2);
				}
			}
		}
		return (it.getValue().state == 1);
	}
	/**
	 * @param x1 abscisse du premier point
	 * @param y1 ordonnée du premier point
	 * @param x2 abscisse du deuxième point
	 * @param y2 ordonnée du deuxième point
	 * @pre !this.isEmpty()
	 * @return true si les deux points (x1, y1) et (x2, y2) sont représentés par la
	 *         même feuille de this, false sinon
	 */
	@Override
	public boolean sameLeaf(int x1, int y1, int x2, int y2) {
		Iterator<Node> it = this.iterator();
		int xMin = 0;
		int xMax = 255;
		int yMin = 0;
		int yMax = 255;
		int v = 0;
		while (it.nodeType() == NodeType.DOUBLE) {
			if (v == 1) {
				if (x1 > (xMin + xMax) / 2 && x2 > (xMin + xMax) / 2) {
					it.goRight();
					xMin = (xMin + xMax) / 2;
					v = 0;
				} else if (x1 <= (xMin + xMax) / 2 && x2 <= (xMin + xMax) / 2) {
					it.goLeft();
					xMax = (xMin + xMax) / 2;
					v = 0;
				} else {
					return false;
				}
			}else {
				if (y1 > (yMin + yMax) / 2 && y2 > (yMin + yMax) / 2) {
					it.goRight();
					yMin = (yMin + yMax) / 2;
					v = 1;
				} else if (y1 <= (yMin + yMax) / 2 && y2 <= (yMin + yMax) / 2) {
					it.goLeft();
					yMax = (yMin + yMax) / 2;
					v = 1;
				} else {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * @param image2 autre image
	 * @pre !this.isEmpty() && !image2.isEmpty()
	 * @return true si this est incluse dans image2 au sens des pixels allumés false
	 *         sinon
	 */
	@Override
	public boolean isIncludedIn(AbstractImage image2) {
		Iterator <Node> it2 = image2.iterator();
		Iterator <Node> it = this.iterator();
		return AuxisIncludedIn(it,it2);
	}

	public boolean AuxisIncludedIn(Iterator <Node> it,Iterator <Node>it2 ) {
		if((it2.getValue().state==1 && it.getValue().state!=1)||
				(it.getValue().state==0 && it2.getValue().state==2)) {
			return true;	
		}																															
		else if(it2.getValue().state==2 && it.getValue().state==2) {
			it.goLeft();
			it2.goLeft();
			if(AuxisIncludedIn(it,it2)) {
				it.goUp();
				it2.goUp();
				it.goRight();
				it2.goRight();
				if(AuxisIncludedIn(it,it2)) return true ;
			}
			it.goUp();
			it2.goUp();
		}
		return false ;
	}


}